<p style="background-color: #333" class="text-sm mb-4 leading-normal link">
    <a style="color: #fff; padding: 10px 5px; display: block" class="text-white inline-flex">
        <img style="max-width: 18px; margin-right: 5px; margin-bottom: -5px" class="link-icon" src="<?php block_field("link-icon"); ?>"><?php block_field("link-text"); ?>
    </a> 
</p>