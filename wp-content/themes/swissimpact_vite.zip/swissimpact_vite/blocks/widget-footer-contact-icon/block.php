<p class="text-sm mb-4 leading-normal link">
    <a href="<?php block_field("link-url"); ?>" class="text-white inline-flex">
        <img class="link-icon" src="<?php block_field("link-icon"); ?>"><span class="ml-2"><?php block_field("link-text"); ?></span>
    </a> 
</p>