<a class="btn transparent text-center">
    <?php block_field("cta-btn-text") ?>
</a>