<a target="<?php echo block_value("cta-btn-open-in-new-tab") == "Yes" ? "_blank" : ""; ?>" class="btn transparent text-center" href="<?php block_field("cta-btn-url"); ?>">
    <?php block_field("cta-btn-text"); ?>
</a>